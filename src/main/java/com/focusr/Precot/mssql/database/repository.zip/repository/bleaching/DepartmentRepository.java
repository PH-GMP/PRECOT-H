
package com.focusr.Precot.mssql.database.repository.bleaching;

import java.util.Optional;

import org.hibernate.validator.constraints.Range;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.focusr.Precot.mssql.database.model.bleaching.Department;


@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long>{

	Optional<Department> findById(Long id);
	
}
