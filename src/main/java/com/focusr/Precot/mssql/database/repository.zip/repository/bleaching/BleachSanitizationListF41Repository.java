package com.focusr.Precot.mssql.database.repository.bleaching;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.focusr.Precot.mssql.database.model.bleaching.BleachSanitizationListF41;

@Repository
public interface BleachSanitizationListF41Repository extends JpaRepository<BleachSanitizationListF41, Long>{

}
