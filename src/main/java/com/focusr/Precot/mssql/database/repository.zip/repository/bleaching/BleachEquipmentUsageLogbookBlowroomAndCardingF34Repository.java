package com.focusr.Precot.mssql.database.repository.bleaching;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.focusr.Precot.mssql.database.model.bleaching.BleachEquipmentUsageLogbookBlowroomAndCardingF34;

@Repository
public interface BleachEquipmentUsageLogbookBlowroomAndCardingF34Repository
		extends JpaRepository<BleachEquipmentUsageLogbookBlowroomAndCardingF34, Long> {

	@Query(value = "SELECT b FROM BleachEquipmentUsageLogbookBlowroomAndCardingF34 b WHERE b.supervisor_status = 'SUPERVISOR_SAVED' ORDER BY EQUIPB_ID DESC", nativeQuery = true)
	List<BleachEquipmentUsageLogbookBlowroomAndCardingF34> getsummaryForSupervisor();

	@Query(value = "SELECT b FROM BleachEquipmentUsageLogbookBlowroomAndCardingF34 b WHERE b.supervisor_status = 'SUPERVISOR_APPROVED' AND b.hod_status !='HOD_APPROVED' AND b.mail_status = 'WAITING_FOR_APPROVAL' ORDER BY EQUIPB_ID DESC", nativeQuery = true)
	List<BleachEquipmentUsageLogbookBlowroomAndCardingF34> getsummaryForHod();

//	@Query(value = "SELECT * FROM BLEACH_EQUIPMENT_USAGE_LOGBOOK_BLOWROOM_AND_CARDING_F34 WHERE BMR_NUMBER = :bmrNumber", nativeQuery = true)
//	List<BleachEquipmentUsageLogbookBlowroomAndCardingF34> getByBmrNo(@Param("bmrNumber") String bmrNumber);
	
	@Query(value = "SELECT * FROM BLEACH_EQUIPMENT_USAGE_LOGBOOK_BLOWROOM_AND_CARDING_F34 WHERE BMR_NUMBER = :bmrNumber", nativeQuery = true)
	BleachEquipmentUsageLogbookBlowroomAndCardingF34 getByBmrNo(@Param("bmrNumber") String bmrNumber);

	@Query(value = "SELECT b FROM BleachEquipmentUsageLogbookBlowroomAndCardingF34 b "
			+ "WHERE b.bmrNumber BETWEEN :fromBmrNumber AND :toBmrNumber AND b.hod_status = 'HOD_APPROVED' ORDER BY EQUIPB_ID DESC", nativeQuery = true)
	List<BleachEquipmentUsageLogbookBlowroomAndCardingF34> findByBmrNumberRange(
			@Param("fromBmrNumber") String fromBmrNumber, @Param("toBmrNumber") String toBmrNumber);
}
