package com.focusr.Precot.mssql.database.repository.bleaching;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.focusr.Precot.mssql.database.model.bleaching.BleachEquipmentUsageLogBookCakePressF09;
import com.focusr.Precot.payload.BmrTimeRange;

@Repository
public interface BleachEquipmentUsageLogBookCakePressF09Repository
		extends JpaRepository<BleachEquipmentUsageLogBookCakePressF09, Long> {

	@Query(value = "SELECT * FROM BLEACH_EQUIPMENT_USAGE_LOGBOOK_CAKE_PRESS_F09 WHERE EQUIPC_ID = :equipc_id", nativeQuery = true)
	BleachEquipmentUsageLogBookCakePressF09 getDetailsById(@Param("equipc_id") Long equipc_id);

	@Query(value = "SELECT b FROM BleachEquipmentUsageLogBookCakePressF09 b WHERE b.supervisor_status = 'SUPERVISOR_SAVED' ORDER BY EQUIPC_ID DESC", nativeQuery = true)
	List<BleachEquipmentUsageLogBookCakePressF09> getsummaryForSupervisor();

	@Query(value = "SELECT b FROM BleachEquipmentUsageLogBookCakePressF09 b WHERE b.supervisor_status = 'SUPERVISOR_APPROVED' AND b.hod_status !='HOD_APPROVED' AND b.mail_status = 'WAITING_FOR_APPROVAL' ORDER BY EQUIPC_ID DESC", nativeQuery = true)
	List<BleachEquipmentUsageLogBookCakePressF09> getsummaryForHod();

	@Query(value = "SELECT * FROM BLEACH_EQUIPMENT_USAGE_LOGBOOK_CAKE_PRESS_F09 WHERE BMR_NUMBER = :bmr_number", nativeQuery = true)
	List<BleachEquipmentUsageLogBookCakePressF09> getDetailsByBMR(@Param("bmr_number") String bmr_number);

	@Query(value = "SELECT SUBBATCH_NO FROM BLEACH_EQUIPMENT_USAGE_LOGBOOK_CAKE_PRESS_F09 WHERE BMR_NUMBER=:bmr_no", nativeQuery = true)
	List<String> getBatchByBMR(@Param("bmr_no") String bmr_no);

//    @Query(value = "SELECT MIN(START_DATE) AS startDate, MIN(START_TIME) AS startTime, MAX(END_DATE) AS endDate, MIN(END_TIME) AS endTime FROM BLEACH_EQUIPMENT_USAGE_LOGBOOK_CAKE_PRESS_F09 WHERE BMR_NUMBER=:bmr_number", nativeQuery = true)
//    BmrTimeRange getStartEndTime(@Param("bmr_number") String bmr_number);

	@Query(value = "SELECT MIN(START_DATE) AS startDate, MIN(START_TIME) AS startTime, MAX(END_DATE) AS endDate, MAX(END_TIME) AS endTime FROM BLEACH_EQUIPMENT_USAGE_LOGBOOK_CAKE_PRESS_F09 WHERE BMR_NUMBER = :bmr_number", nativeQuery = true)
	BmrTimeRange getStartEndTime(@Param("bmr_number") String bmrNumber);
	

	@Query(value = "SELECT MIN(CONCAT(START_DATE, ' ', START_TIME)) AS StartDateTime FROM BLEACH_EQUIPMENT_USAGE_LOGBOOK_CAKE_PRESS_F09 WHERE BMR_NUMBER=:bmr_number", nativeQuery = true)
	String startDateBMR(@Param("bmr_number") String bmr_number);

	@Query(value = "SELECT MIN(CONCAT(END_DATE, ' ', END_TIME)) AS StartDateTime FROM BLEACH_EQUIPMENT_USAGE_LOGBOOK_CAKE_PRESS_F09 WHERE BMR_NUMBER=:bmr_number", nativeQuery = true)
	String endDateBMR(@Param("bmr_number") String bmr_number);

	@Query(value = "SELECT b FROM BleachEquipmentUsageLogBookCakePressF09 b "
			+ "WHERE b.bmrNumber BETWEEN :fromBmrNumber AND :toBmrNumber AND b.hod_status = 'HOD_APPROVED' ORDER BY EQUIPC_ID DESC", nativeQuery = true)
	List<BleachEquipmentUsageLogBookCakePressF09> findByBmrNumberRange(@Param("fromBmrNumber") String fromBmrNumber,
			@Param("toBmrNumber") String toBmrNumber);
	
//	@Query(value = "SELECT * FROM BLEACH_EQUIPMENT_USAGE_LOGBOOK_CAKE_PRESS_F09 WHERE BMR_NUMBER = :bmrNumber AND SUBBATCH_NO = :subbatchNo", nativeQuery = true)
//	List<BleachEquipmentUsageLogBookCakePressF09> findByBmrNumberAndSubbatch_no(String bmrNumber, String subbatchNo);

	@Query(value = "SELECT * FROM BLEACH_EQUIPMENT_USAGE_LOGBOOK_CAKE_PRESS_F09 WHERE BMR_NUMBER = :bmrNumber AND SUBBATCH_NO = :subbatchNo", nativeQuery = true)
	BleachEquipmentUsageLogBookCakePressF09 findByBmrNumberAndSubbatch_no(String bmrNumber, String subbatchNo);


}
