package com.focusr.Precot.mssql.database.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.focusr.Precot.mssql.database.model.bleaching.lov.PhBasedSupplier;

public interface PhBasedSupplierRepository extends JpaRepository<PhBasedSupplier,Long>{

}
