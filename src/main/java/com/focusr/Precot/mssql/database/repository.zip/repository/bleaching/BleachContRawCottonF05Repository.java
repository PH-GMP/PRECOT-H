package com.focusr.Precot.mssql.database.repository.bleaching;
 
import java.util.List;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
 
import com.focusr.Precot.mssql.database.model.bleaching.BleachAppliedContRawCottonF04;
import com.focusr.Precot.mssql.database.model.bleaching.BleachContAbsBleachedCottonF18;
import com.focusr.Precot.mssql.database.model.bleaching.BleachContRawCottonF05;
import com.focusr.Precot.mssql.database.model.bleaching.MetalDetectorCheckListF03;
 
@Repository
public interface BleachContRawCottonF05Repository extends JpaRepository<BleachContRawCottonF05,Long>
{
	@Query(value = "SELECT * FROM BLEACH_CONT_RAWCOTTON_F05 WHERE ID = :id ", nativeQuery = true)
	BleachContRawCottonF05 findFormById(@Param("id") long id);
	
	@Query(value = "SELECT * FROM BLEACH_CONT_RAWCOTTON_F05 WHERE FORMAT_NO = :formatNo",nativeQuery = true)
	List<BleachContRawCottonF05> getDetailsByFormatNo(@Param("formatNo") String formatNo);
	
	@Query(value = "SELECT * FROM BLEACH_CONT_RAWCOTTON_F05 WHERE FORMAT_NO =:format_no", nativeQuery = true)
	List<BleachContRawCottonF05> findByListOfF05FormatDetails(@Param("format_no") String formatNo);
	
	@Query(value = "SELECT * FROM BLEACH_CONT_RAWCOTTON_F05 WHERE PH_NO =:phNo", nativeQuery = true)
	List<BleachContRawCottonF05> findByPHDetails(@Param("phNo") String phNo);
	
//	@Query(value = "SELECT * FROM BLEACH_CONT_RAWCOTTON_F05 WHERE SUPERVISOR_STATUS = 'SUPERVISOR_SAVED'", nativeQuery = true)
//	List<BleachContRawCottonF05> findBySupervisorStatusSavedAndNotApproved();
	
//	@Query(value = "SELECT * FROM BLEACH_CONT_RAWCOTTON_F05 WHERE SUPERVISOR_STATUS ='SUPERVISOR_SAVED' AND SUPERVISOR_SAVED_ID =:supervisor_saved_id", nativeQuery = true)
//	List<BleachContRawCottonF05> findBySupervisorStatusSavedAndNotApproved(@Param("supervisor_saved_id") Long supervisor_saved_id);

	@Query(value = "SELECT * FROM BLEACH_CONT_RAWCOTTON_F05 WHERE SUPERVISOR_STATUS ='SUPERVISOR_SAVED' ORDER BY ID DESC", nativeQuery = true)
	List<BleachContRawCottonF05> findBySupervisorStatusSavedAndNotApproved();

	
	@Query(value = "SELECT * FROM BLEACH_CONT_RAWCOTTON_F05 WHERE SUPERVISOR_STATUS = 'SUPERVISOR_APPROVED' AND HOD_STATUS != 'HOD_APPROVED' ORDER BY ID DESC", nativeQuery = true)
	List<BleachContRawCottonF05> findBySupervisorStatusApprovedAndHodStatusNotApproved();
	
//	@Query(value = "SELECT * FROM BLEACH_CONT_RAWCOTTON_F05 WHERE SUPERVISOR_STATUS = 'SUPERVISOR_APPROVED'", nativeQuery = true)
//	List<BleachContRawCottonF05> findBySupervisorStatusApprovedAndHodStatusNotApproved();
	
	@Query(value = "SELECT * FROM BLEACH_CONT_RAWCOTTON_F05 WHERE DATE = :date AND HOD_STATUS = 'HOD_APPROVED' ORDER BY ID DESC", nativeQuery = true)
	List<BleachContRawCottonF05> findByDate(@Param("date") String date);

}