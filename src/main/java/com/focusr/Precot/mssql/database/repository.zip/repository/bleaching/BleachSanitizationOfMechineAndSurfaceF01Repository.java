package com.focusr.Precot.mssql.database.repository.bleaching;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.focusr.Precot.mssql.database.model.bleaching.BleachSanitizationOfMechineAndSurfaceF01;




@Repository
public interface BleachSanitizationOfMechineAndSurfaceF01Repository extends JpaRepository<BleachSanitizationOfMechineAndSurfaceF01, Long>{

	 @Query(value = "SELECT * FROM BLEACH_SANITIZATION_OF_MECHINE_AND_SURFACE_F01 WHERE SMS_ID = :sms_id", nativeQuery = true)
	 BleachSanitizationOfMechineAndSurfaceF01 getDetailsById(@Param("sms_id") Long sms_id);

	@Query(value = "SELECT * FROM BLEACH_SANITIZATION_OF_MECHINE_AND_SURFACE_F01 WHERE FORMAT_NO =:formatNo", nativeQuery = true)
	List<BleachSanitizationOfMechineAndSurfaceF01> findFormatDetailsF36(@Param("formatNo") String formatNo);
	
	 @Query("SELECT b FROM BleachSanitizationOfMechineAndSurfaceF01 b WHERE b.month = :month and b.year = :year")
	 List<BleachSanitizationOfMechineAndSurfaceF01> findByMonthAndYear(@Param("month") String month, @Param("year") String year);
	 
	  @Query(value="SELECT b FROM BleachSanitizationOfMechineAndSurfaceF01 b WHERE b.supervisor_status = 'SUPERVISOR_SAVED' ORDER BY SMS_ID DESC", nativeQuery = true)
	    List<BleachSanitizationOfMechineAndSurfaceF01> getsummaryForSupervisor();

	    @Query(value="SELECT b FROM BleachSanitizationOfMechineAndSurfaceF01 b WHERE b.supervisor_status = 'SUPERVISOR_APPROVED' AND b.hod_status !='HOD_APPROVED' AND b.mail_status = 'WAITING_FOR_APPROVAL' ORDER BY SMS_ID DESC", nativeQuery = true)
	    List<BleachSanitizationOfMechineAndSurfaceF01> getsummaryForHod();
	    
	    @Query(value = "SELECT * FROM BLEACH_SANITIZATION_OF_MECHINE_AND_SURFACE_F01 WHERE MONTH = :month AND YEAR =:year AND WEEK = :week" , nativeQuery = true)
		List< BleachSanitizationOfMechineAndSurfaceF01> getdateSanitizationMechineAndSurfaceDetails(@Param("month") String month,@Param("year") String year, @Param("week") String week);
	  
//	  @Query("SELECT b FROM BleachSanitizationOfMechineAndSurfaceF01 b WHERE b.supervisor_status = 'SUPERVISOR_APPROVED'")
//	    List<BleachSanitizationOfMechineAndSurfaceF01> getsummaryForHod();
}
