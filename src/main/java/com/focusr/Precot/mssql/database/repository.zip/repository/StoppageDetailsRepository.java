package com.focusr.Precot.mssql.database.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.focusr.Precot.mssql.database.model.Stoppage;

import com.focusr.Precot.mssql.database.model.bleaching.lov.BaleNumbers;
import com.focusr.Precot.payload.GetStoppageDetailsResponse;
import com.focusr.Precot.payload.ShoppageDetails;

@Repository
public interface StoppageDetailsRepository  extends JpaRepository<Stoppage, Long> {
	
//	@Query("SELECT * FROM SplB b WHERE b.pack_dt = :pack_dt AND b.shift_id = :shift_id")
	 @Query(value = "SELECT ts.MCN AS mcn ,ts.FTime AS f_time ,ts.TTime AS t_time ,ts.Scause AS s_cause FROM tblSBlg ts WHERE PackDt=:date AND ShiftID =:shift_id", nativeQuery = true)
		List<GetStoppageDetailsResponse> findByDateAndShift(@Param("date") String date, @Param("shift_id") String shift_id);

}
