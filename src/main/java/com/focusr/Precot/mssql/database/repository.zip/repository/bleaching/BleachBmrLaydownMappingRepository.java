package com.focusr.Precot.mssql.database.repository.bleaching;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.focusr.Precot.mssql.database.model.bleaching.BleachBmrLaydownMapping;
import com.focusr.Precot.payload.BMRProductionDetailsResponse;
import com.focusr.Precot.payload.BMRProductionResponseLaydown;
import com.focusr.Precot.payload.BleachingWasteBaleResponse;
import com.focusr.Precot.payload.RawCottonIssueResponse;
import com.focusr.Precot.payload.ShoppageDetails;
import com.focusr.Precot.payload.TableRMResponse;

public interface BleachBmrLaydownMappingRepository extends JpaRepository<BleachBmrLaydownMapping, Long> {

//	@Query(value="SELECT POrder FROM OrderInfo WHERE Material LIKE 'AB%' AND CMon >= '2024-06-01'",nativeQuery=true)
//	List<Map<Long,String>> getJobCardDetails()

//	@Query(value = "SELECT POrder FROM OrderInfo WHERE Material LIKE 'AB%' AND CMon >= '2024-06-01'", nativeQuery = true)
//	List<Map<String, Object>> getJobCardDetails();
//	
	

//	@Query(value = "SELECT DISTINCT mix FROM tblOrderInfo", nativeQuery = true)
//	List<Map<String, Object>> getMixingLov();

	@Query(value = " SELECT BMR_NO FROM BLEACH_BMR_LAYDOWN_MAPPING WHERE STATUS ='OPEN' ORDER BY ID DESC", nativeQuery = true)
	List<Map<String, Object>> getMappingBmr();

	@Query(value = "SELECT * FROM BLEACH_BMR_LAYDOWN_MAPPING WHERE BMR_NO = :MappingBmr_No", nativeQuery = true)
	List<BleachBmrLaydownMapping> getLaydownNo(@Param("MappingBmr_No") String MappingBmr_No);

	@Query(value = "SELECT * FROM BLEACH_BMR_LAYDOWN_MAPPING WHERE LAYDOWN_NO = :MappingBmr_No", nativeQuery = true)
	List<BleachBmrLaydownMapping> getBMRNumber(@Param("MappingBmr_No") String MappingBmr_No);

	@Query(value = " SELECT LAYDOWN_NO FROM BLEACH_BMR_LAYDOWN_MAPPING WHERE STATUS ='OPEN' ORDER BY ID DESC", nativeQuery = true)
	List<Map<String, Object>> getMappingLaydown();

	@Query(value = "SELECT DISTINCT BaleNo FROM tblBalePack tbp WHERE bmr_no=:bmr_no", nativeQuery = true)
	List<String> fetchBaleFromBMR(@Param("bmr_no") String bmr_no);

	@Query(value = "SELECT * FROM BLEACH_BMR_LAYDOWN_MAPPING WHERE BMR_NO = :MappingBmr_No", nativeQuery = true)
	BleachBmrLaydownMapping getBMRNoResponse(@Param("MappingBmr_No") String MappingBmr_No);
	
	//GET BMR AND LAYDOWN LOV
	
	@Query(value = "SELECT * FROM BLEACH_BMR_LAYDOWN_MAPPING bblm ORDER BY ID DESC", nativeQuery = true)
	List<BleachBmrLaydownMapping> fetchBMRAndLaydownLov();

	// USING 3rd PARTy Table
	
	
	@Query(value = "SELECT POrder FROM tblOrderInfo WHERE Material LIKE 'AB%' AND Sts = 1", nativeQuery = true)
	List<Map<String, Object>> getJobCardDetails();

	@Query(value = "SELECT DISTINCT mix FROM tblOrderInfo WHERE POrder=:order", nativeQuery = true)
	List<Map<String, Object>> getMixingLov(@Param("order") String order);

	@Query(value = "SELECT DISTINCT BatchNo FROM tblBalePack tbp WHERE bmr_no=:bmr_no", nativeQuery = true)
	List<BigDecimal> fetchBatchNoFromBMR(@Param("bmr_no") String bmr_no);

	@Query(value = "SELECT DISTINCT BaleNo FROM tblBalePack tbp WHERE BatchNo=:batch_no", nativeQuery = true)
	List<String> fetchBaleNoFromBatch(@Param("batch_no") BigDecimal batch_no);

	@Query(value = "SELECT DISTINCT BatchNo FROM tblBalePack WHERE BatchNo > 4680 AND BMR_NO IS NULL", nativeQuery = true)
	List<Integer> fetchBMRfromSAP();

	@Query(value = "SELECT DISTINCT BatchNo FROM tblBalePack WHERE BatchNo > 4680 AND BMR_NO IS NULL", nativeQuery = true)
	List<BigDecimal> fetchBMRfromSAP1();

	@Modifying
	@Transactional
	@Query(value = "UPDATE tblBalePack SET BMR_NO = :bmrNo WHERE BatchNo IN (:batchNos)", nativeQuery = true)
	int updateBmrNo(@Param("bmrNo") String bmrNo, @Param("batchNos") List<Integer> batchNos);

	@Query(value = "SELECT DISTINCT BaleNo FROM tblBalePack tbp WHERE BatchNo=:batch_no AND bmr_no=:bmr_no", nativeQuery = true)
	List<String> fetchBaleNoFromBatch(@Param("batch_no") BigDecimal batch_no, @Param("bmr_no") String bmr_no);

	@Query(value = "SELECT Batchno AS batchNo, Supplier AS supplier, Date AS date " + "FROM tblrm "
			+ "WHERE mvt_type = 101 " + "AND TRY_CONVERT(DATE, Date, 103) >= DATEADD(DAY, -5, CAST(GETDATE() AS DATE)) "
			+ "AND TRY_CONVERT(DATE, Date, 103) <= CAST(GETDATE() AS DATE)", nativeQuery = true)
	List<TableRMResponse> rmDataList();

	@Query(value = "SELECT Batchno AS batchNo, Weight AS weight, Noofbales AS balesCount FROM tblrm WHERE mvt_type = 101 AND laydownno=:laydown_no", nativeQuery = true)
	List<RawCottonIssueResponse> rawCottonResponse(@Param("laydown_no") String laydown_no);
	
		/** 
		 * For WASTE BALE PRESS - tblrejbale
		 */
	
//	@Query(value = "SELECT BaleNo AS baleNo, POrder AS orderNo, GrsWt AS grossweight, NetWt AS netweight FROM tblrejbale WHERE PackDt=:date", nativeQuery = true)
//	List<BleachingWasteBaleResponse> wastePressBaleResponse(@Param("date") String date); 
//	@Query(value = "SELECT BaleNo AS bale_no, POrder AS waste_code, GrsWt AS gross_weight, NetWt AS net_weight FROM tblrejbale WHERE PackDt=:date", nativeQuery = true)
//	List<BleachingWasteBaleResponse> wastePressBaleResponse(@Param("date") String date); 

	/**
	 *  BMR SUMMARY 
	 */
	
	@Query(value = "SELECT MIN(BatchNo) AS startSubBatch, MAX(BatchNo) AS endSubBatch, COUNT(DISTINCT BatchNo) AS batchCount, COUNT(DISTINCT BaleNo) AS baleCount, MIN(isExport) AS isExport, MIN(isCons) AS isHouse FROM tblBalePack WHERE BMR_NO = :bmr_no", nativeQuery = true)
    BMRProductionDetailsResponse productionDetailsResponse(@Param("bmr_no") String bmr_no);

    @Query(value = "SELECT Qty AS quantity, Mix AS mixing, FinishDesc AS finishing FROM tblOrderInfo WHERE POrder=:order AND Sts =1", nativeQuery = true)
    BMRProductionResponseLaydown productionResponseLaydown(@Param("order") String order);
	
//	@Query(value = "SELECT MIN(BatchNo) AS startSubBatch, SELECT MAX(BatchNo) AS endSubBatch, COUNT(DISTINCT(BatchNo)) AS batchCount, COUNT(DISTINCT(BaleNo)) AS baleCount FROM tblBalePack WHERE BMR_NO=:bmr_no", nativeQuery = true)
//	BMRProductionDetailsResponse productionDetailsResponse(@Param("bmr_no") String bmr_no);
//	
//	@Query(value = "SELECT Qty AS quantity, Mix AS mixing, Finish AS finishing FROM tblrm WHERE laydownno=:laydown_no", nativeQuery = true)
//	BMRProductionResponseLaydown productionResponseLaydown(@Param("laydown_no") String laydown_no);
    
    /**
     * SHOPPAGE DETAILS
     */
	
    @Query(value = "SELECT PackDt AS packDt, FTime AS fromHours, TTime AS toHours, SCause AS sCause, TotHrs AS totalHours FROM SplB WHERE PackDt=:date", nativeQuery = true)
    List<ShoppageDetails> getShoppageDetailsForDate(@Param("date") String date); 
    
    
   @Query(value = "SELECT BaleNo AS baleNo, POrder AS orderNo, GrsWt AS grossweight, NetWt AS netweight FROM tblrejbale", nativeQuery = true)
   List<BleachingWasteBaleResponse> wastePressBaleResponsenew();
   
//   @Query(value = "SELECT PackDt AS packDt, FTime AS fromHours, TTime AS toHours, SCause AS sCause, TotHrs AS totalHours FROM SplB WHERE PackDt=:date AND ShiftID =:shift_id", nativeQuery = true)
//	List<ShoppageDetails> findByDateAndShift(@Param("date") String date, @Param("shift_id") String shift_id);
   
//   @Query(value = "SELECT PackDt AS packDt, FTime AS fromHours, TTime AS toHours, SCause AS sCause, TotHrs AS totalHours FROM tblSBlg WHERE PackDt=:date AND ShiftID =:shift_id", nativeQuery = true)
//	List<ShoppageDetails> findByDateAndShift(@Param("date") String date, @Param("shift_id") String shift_id);

   @Query(value = "SELECT BaleNo AS bale_no, POrder AS waste_code, GrsWt AS gross_weight, NetWt AS net_weight FROM tblrejbale WHERE PackDt=:date AND POrder Not in ('rejbale')", nativeQuery = true)
	List<BleachingWasteBaleResponse> wastePressBaleResponse(@Param("date") String date);
    
}
