package com.focusr.Precot.mssql.database.repository.bleaching;

import org.springframework.data.jpa.repository.JpaRepository;

import com.focusr.Precot.mssql.database.model.bleaching.ChemicalDetails_BMR;

public interface ChemicalDetails_BMRRepository extends JpaRepository<ChemicalDetails_BMR,Long>{

}
