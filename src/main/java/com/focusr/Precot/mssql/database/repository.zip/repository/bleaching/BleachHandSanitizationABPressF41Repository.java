package com.focusr.Precot.mssql.database.repository.bleaching;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.focusr.Precot.mssql.database.model.bleaching.BleachHandSanitizationABPressF41;
import com.focusr.Precot.mssql.database.model.bleaching.BleachMixingChangeMachineCleaningF38;
import com.focusr.Precot.mssql.database.model.bleaching.BleachShiftLogBookF36;

@Repository
public interface BleachHandSanitizationABPressF41Repository
		extends JpaRepository<BleachHandSanitizationABPressF41, Long> {

	@Query(value = "SELECT * FROM BLEACH_HAND_SANITIZATION_AB_PRESS_F41 WHERE HAND_SANITIZATION_ID=:id", nativeQuery = true)
	Optional<BleachHandSanitizationABPressF41> getHandSanitizationABPressF41ById(@Param("id") Long id);

	@Query(value = "SELECT * FROM BLEACH_HAND_SANITIZATION_AB_PRESS_F41 WHERE HAND_SANITIZATION_ID=:id", nativeQuery = true)
	BleachHandSanitizationABPressF41 fetchHandSanitizationABPressF41ById(@Param("id") Long id);

	@Query(value = "SELECT * FROM BLEACH_HAND_SANITIZATION_AB_PRESS_F41 WHERE DATE=:date", nativeQuery = true)
	Optional<BleachHandSanitizationABPressF41> getHandSanitizationABPressF41ByDate(@Param("date") String date);

	@Query(value = "SELECT * FROM BLEACH_HAND_SANITIZATION_AB_PRESS_F41 WHERE FORMAT_NO =:formatNo", nativeQuery = true)
	List<BleachHandSanitizationABPressF41> findFormatDetailsF41(@Param("formatNo") String formatNo);

	@Query(value = "SELECT * FROM BLEACH_HAND_SANITIZATION_AB_PRESS_F41 WHERE SUPERVISIOR_STATUS IN ('SUPERVISIOR_SUBMITTED') AND HOD_APPROVER_STATUS IN ('WAITING_FOR_APPROVAL', 'HOD_SUBMITTED') AND HOD_MAIL_STATUS IN ('WAITING_FOR_APPROVAL', 'HOD_SUBMITTED') ORDER BY HAND_SANITIZATION_ID DESC", nativeQuery = true)
	List<BleachHandSanitizationABPressF41> submittedHandSanitization();

	@Query(value = "SELECT b FROM BleachHandSanitizationABPressF41 b WHERE b.date = :date AND b.shift = :shift", nativeQuery = true)
	List<BleachHandSanitizationABPressF41> findByDateAndShift(@Param("date") String date, @Param("shift") String shift);

	@Query(value = "SELECT b FROM BleachHandSanitizationABPressF41 b WHERE b.supervisor_status = 'SUPERVISOR_SAVED' ORDER BY HAND_SANITIZATION_ID DESC", nativeQuery = true)
	List<BleachHandSanitizationABPressF41> getsummaryForSupervisor();

	@Query(value = "SELECT b FROM BleachHandSanitizationABPressF41 b WHERE b.supervisor_status = 'SUPERVISOR_APPROVED' AND b.hod_status !='HOD_APPROVED' AND b.mail_status = 'WAITING_FOR_APPROVAL' ORDER BY HAND_SANITIZATION_ID DESC", nativeQuery = true)
	List<BleachHandSanitizationABPressF41> getsummaryForHod();
	
//	@Query("SELECT b FROM BleachHandSanitizationABPressF41 b WHERE b.supervisor_status = 'SUPERVISOR_APPROVED'")
//	List<BleachHandSanitizationABPressF41> getsummaryForHod();

}
