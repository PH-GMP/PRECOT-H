package com.focusr.Precot.mssql.database.repository.bleaching;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.focusr.Precot.mssql.database.model.bleaching.BleachSanitizationOfMechineAndSurfaceF01;
import com.focusr.Precot.mssql.database.model.bleaching.BleachShiftLogBookF36;

@Repository
public interface BleachShiftLogBookF36Repository extends JpaRepository<BleachShiftLogBookF36, Long>{
	
	@Query(value = "SELECT * FROM BLEACH_SHIFT_LOGBOOK_F36 WHERE SLB_ID = :slb_id", nativeQuery = true)
	BleachShiftLogBookF36 getdetaisById(@Param("slb_id") Long slb_id);
	
	@Query(value = "SELECT * FROM BLEACH_SHIFT_LOGBOOK_F36 WHERE FORMAT_NO =:formatNo", nativeQuery = true)
	List<BleachShiftLogBookF36> findFormatDetailsF36(@Param("formatNo") String formatNo);

	 @Query("SELECT b FROM BleachShiftLogBookF36 b WHERE b.date = :date AND b.shift = :shift")
	 List<BleachShiftLogBookF36> findByDateAndShift(@Param("date") String date, @Param("shift") String shift);


	 @Query("SELECT b FROM BleachShiftLogBookF36 b WHERE b.supervisor_status = 'SUPERVISOR_SAVED' order by date DESC ")
	    List<BleachShiftLogBookF36> getsummaryForSupervisor();

	    @Query("SELECT b FROM BleachShiftLogBookF36 b WHERE b.supervisor_status = 'SUPERVISOR_APPROVED' AND b.hod_status !='HOD_APPROVED' AND b.mail_status = 'WAITING_FOR_APPROVAL' order by date DESC")
	    List<BleachShiftLogBookF36> getsummaryForHod();
	 
//	 @Query("SELECT b FROM BleachShiftLogBookF36 b WHERE b.supervisor_status = 'SUPERVISOR_APPROVED'")
//	    List<BleachShiftLogBookF36> getsummaryForHod();
	    
	    @Query(value="SELECT * FROM BLEACH_SHIFT_LOGBOOK_F36 WHERE HOD_STATUS ='HOD_APPROVED' ORDER BY DATE DESC", nativeQuery = true)
	    List<BleachShiftLogBookF36> getsummaryPrint();
}
