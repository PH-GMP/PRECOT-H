package com.focusr.Precot.mssql.database.repository.bleaching;

import org.springframework.data.jpa.repository.JpaRepository;

import com.focusr.Precot.mssql.database.model.bleaching.PackingDetails_BMR;

public interface PackingDetails_BMRRepository extends JpaRepository<PackingDetails_BMR,Long>{

}
