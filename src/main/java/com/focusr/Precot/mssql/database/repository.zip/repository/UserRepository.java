package com.focusr.Precot.mssql.database.repository;

import java.util.List;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;

import org.springframework.data.repository.query.Param;

import org.springframework.stereotype.Repository;

import com.focusr.Precot.mssql.database.model.Role;
import com.focusr.Precot.mssql.database.model.User;
import com.focusr.Precot.payload.UserDTO;
import com.focusr.Precot.util.BleachHodHrQaDetails;

/**
 * 
 * Created by FocusR .
 * 
 */

@Repository

public interface UserRepository extends JpaRepository<User, Long> {

	@Override

	List<User> findAll();

	Optional<User> findByEmail(String email);

	Optional<User> findByUsernameOrEmail(String username, String email);

	List<User> findByIdIn(List<Long> userIds);

	Optional<User> findByUsername(String username);

	Boolean existsByUsername(String username);

	Boolean existsByEmail(String email);

	@Query(value = "SELECT * FROM USER_LOGIN_DETAILS a WHERE name = :name ", nativeQuery = true)

	List<User> findByFirstNameAndLastName(@Param("name") String firstName);

	@Query(value = "SELECT users.* FROM USER_LOGIN_DETAILS users,\n" +

			"ROLES_MAP_BY_USERS user_role_map,\n" +

			"USER_ROLES roles\n" +

			"where \n" +

			"users.id = user_role_map.user_id and\n" +

			"roles.id = user_role_map.role_id "

			+ "-- and roles.id != 1 "

			+ "order by users.id", nativeQuery = true)

	List<User> findListOfUsers();

//   @Query(value = "SELECT * FROM USER_LOGIN_DETAILS WHERE agentId = :agentId AND (is_active is null or is_active = 'Y')", nativeQuery = true)

//   List<User> findByAgentId(@Param("agentId") long agentId);

//   @Query(value = "SELECT * FROM USER_LOGIN_DETAILS WHERE vendorID = :vendorId AND (is_active is null or is_active = 'Y')", nativeQuery = true)

//   List<User> findByVendorId(@Param("vendorId") long vendorId);

	Optional<User> findByResetToken(String resetToken);

	@Query(value = "SELECT users.* FROM USER_LOGIN_DETAILS users,\n" +

			"ROLES_MAP_BY_USERS user_role_map,\n" +

			"USER_ROLES roles\n" +

			"where \n" +

			"users.id = user_role_map.user_id and\n" +

			"roles.id = user_role_map.role_id "

			+ "and roles.id = 1 "

			+ "and users.username = 'sysadmin' "

			+ "order by users.id", nativeQuery = true)

	Optional<User> findFirstAdmin();

	@Query(value = "SELECT * FROM USER_LOGIN_DETAILS WHERE id = :id ", nativeQuery = true)

	Optional<User> findUser(@Param("id") long id);

	@Query(value = "SELECT * FROM USER_LOGIN_DETAILS WHERE id = :id ", nativeQuery = true)

	User findUserByIdToActiveOrInactive(@Param("id") long id);

	void save(Optional<User> user);

	// method to fetch password by email

	// String findPasswordByEmail(String email);

	@Query("SELECT new com.focusr.Precot.payload.UserDTO(u.id, u.username, u.email) FROM User u")

	List<UserDTO> findUserDetails();

	@Query(value = "SELECT * FROM USER_LOGIN_DETAILS u " +

			"JOIN ROLES_MAP_BY_USERS rmu ON u.id = rmu.user_id " +

			"JOIN USER_ROLES ur ON rmu.role_id = ur.id " +

			"WHERE ur.name = :roleName",

			nativeQuery = true)

	List<User> findByRoleName(@Param("roleName") Role role);

	@Query(value = "SELECT USERNAME FROM USER_LOGIN_DETAILS WHERE ID = :id", nativeQuery = true)
	String getUserName(@Param("id") Long id);

	@Query(value = "SELECT * FROM USER_LOGIN_DETAILS WHERE username =:username", nativeQuery = true)
	User getDetailsByUserName(@Param("username") String username);

	@Query(value = "SELECT u.email, u.id, u.username\r\n"
			+ "FROM USER_LOGIN_DETAILS u\r\n"
			+ "JOIN ROLES_MAP_BY_USERS rm ON u.id = rm.user_id\r\n"
			+ "JOIN USER_ROLES r ON rm.role_id = r.id\r\n"
			+ "WHERE u.DEPARTMENT_ID = 1\r\n"
			+ "  AND r.id = 2\r\n"
			+ "  AND u.is_active = 'Y'\r\n"
			, nativeQuery = true)

	BleachHodHrQaDetails getBleachDepartHOD();

	 @Query(value = "SELECT TOP 1 u.email , u.id, u.username" +
             "FROM USER_LOGIN_DETAILS u " +
             "JOIN ROLES_MAP_BY_USERS rm ON u.id = rm.user_id " +
             "JOIN USER_ROLES r ON rm.role_id = r.id " +
             "WHERE" +
             " r.name = 'ROLE_QA'AND u.is_active = 'Y'", nativeQuery = true)
	
	 BleachHodHrQaDetails getQADetails();
	 @Query(value = "SELECT TOP 1 u.email\r\n"
	 		+ "FROM USER_LOGIN_DETAILS u\r\n"
	 		+ "JOIN ROLES_MAP_BY_USERS rm ON u.id = rm.user_id\r\n"
	 		+ "JOIN USER_ROLES r ON rm.role_id = r.id\r\n"
	 		+ "WHERE \r\n"
	 		+ " r.name = 'ROLE_HR'AND u.is_active = 'Y'", nativeQuery = true)
	 BleachHodHrQaDetails getHrDetails();
	 
	@Query(value = "SELECT COUNT(users.DEPARTMENT_ID) AS user_count " +
            "FROM USER_LOGIN_DETAILS users " +
            "JOIN ROLES_MAP_BY_USERS user_role_map ON users.id = user_role_map.user_id " +
            "JOIN USER_ROLES roles ON roles.id = user_role_map.role_id " +
            "WHERE roles.name = 'ROLE_HOD' AND users.DEPARTMENT_ID = :departmentId", nativeQuery = true)
int countUsersWithRoleHodAndDepartmentId(@Param("departmentId") Long departmentId);
}
